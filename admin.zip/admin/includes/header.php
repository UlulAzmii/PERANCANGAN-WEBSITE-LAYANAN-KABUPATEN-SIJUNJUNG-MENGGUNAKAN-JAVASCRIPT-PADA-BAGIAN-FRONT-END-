<?php
$isLoggedIn = isset($_SESSION['user_logged_in']) && $_SESSION['user_logged_in'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <!-- CSS Files -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.materialdesignicons.com/5.4.55/css/materialdesignicons.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <!-- Favicons -->
    <link href="assets/img/service-tool.png" rel="icon">
    <!-- Google Fonts -->
    <link href="https://fonts.gstatic.com" rel="preconnect">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
    <!-- Vendor CSS Files -->
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
    <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
    <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
    <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

    <!-- Include Select2 for searchable dropdowns -->
<!-- <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script> -->

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

</head>
<body>

    <!-- Header -->
    <header id="header" class="header fixed-top d-flex align-items-center">
        <div class="d-flex align-items-center justify-content-between">
            <div class="custom-logo">
                <img src="assets/img/service-tool.png" alt="Logo">
            </div>
            <a class="navbar-brand d-flex align-items-center" href="#">
                <span class="d-none d-lg-block">ADMIN SERVICE SIJUNJUNG</span>
            </a>
            <i class="bi bi-list toggle-sidebar-btn"></i>
        </div>
    </header>

    <!-- Chat Button -->
    <button type="button" class="btn btn-primary chat-button" data-bs-toggle="modal" data-bs-target="#selectOpdModal">
        <i class="bi bi-chat-dots"></i>
    </button>

    <!-- Modal for selecting OPD -->
<div class="modal fade" id="selectOpdModal" tabindex="-1" aria-labelledby="selectOpdModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="selectOpdModalLabel">Select OPD</h5>
            </div>
            <div class="modal-body">
                <div id="opdList" class="opd-list">
                    <!-- OPD chat-like items will be appended here -->
                </div>
            </div>
        </div>
    </div>
</div>



    <!-- Chat Modal -->
    <div class="modal fade" id="chatModal" tabindex="-1" aria-labelledby="chatModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="chatModalLabel">Chat</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="chat-container">
                        <div id="messages" class="messages"></div>
                        <div class="input-container">
                            <textarea id="messageInput" rows="3" class="form-control" placeholder="Type your message..."></textarea>
                            <button id="sendMessage" class="btn btn-primary mt-2">Send</button>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Vendor JS Files -->
    <script src="assets/vendor/apexcharts/apexcharts.min.js" defer></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js" defer></script>
    <script src="assets/vendor/chart.js/chart.umd.js" defer></script>
    <script src="assets/vendor/echarts/echarts.min.js" defer></script>
    <script src="assets/vendor/quill/quill.js" defer></script>
    <script src="assets/vendor/simple-datatables/simple-datatables.js" defer></script>
    <script src="assets/vendor/tinymce/tinymce.min.js" defer></script>
    <script src="assets/vendor/php-email-form/validate.js" defer></script>

    <!-- Template Main JS File -->
    <script src="assets/js/main.js" defer></script>

    <script>
const apiUrl = 'http://192.168.10.6:8080/Kominfo/service-sijunjung/public/Chat.php';
const opdApiUrl = 'http://192.168.10.6:8080/Kominfo/service-sijunjung/public/Opd.php';
let selectedOpdId = localStorage.getItem('id_opd') || null;

function loadOpdList() {
    fetch(opdApiUrl, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            }
        })
        .then(response => response.json())
        .then(data => {
            const opdList = document.getElementById('opdList');
            opdList.innerHTML = ''; // Clear previous list

            data.forEach(item => {
                if (item.id_opd && item.nama_opd) {
                    const opdCard = document.createElement('div');
                    opdCard.className = 'chat-item';

                    const opdAvatar = document.createElement('div');
                    opdAvatar.className = 'chat-avatar';
                    opdAvatar.textContent = item.nama_opd.charAt(0).toUpperCase(); // First letter as avatar

                    const opdDetails = document.createElement('div');
                    opdDetails.className = 'chat-details';

                    const opdName = document.createElement('h5');
                    opdName.className = 'chat-name';
                    opdName.textContent = item.nama_opd;

                    opdDetails.appendChild(opdName);
                    opdCard.appendChild(opdAvatar);
                    opdCard.appendChild(opdDetails);
                    opdList.appendChild(opdCard);

                    opdCard.onclick = () => {
                        selectedOpdId = item.id_opd;
                        localStorage.setItem('id_opd', selectedOpdId);
                        // Close the selection modal and open chat modal
                        const selectOpdModal = new bootstrap.Modal(document.getElementById('selectOpdModal'));
                        selectOpdModal.hide();
                        const chatModal = new bootstrap.Modal(document.getElementById('chatModal'));
                        chatModal.show();
                        loadMessages(); // Load initial messages
                    };
                }
            });
        })
        .catch(error => console.error('Error loading OPD list:', error));
}



// Load chat messages
function loadMessages() {
    if (!selectedOpdId) return;

    fetch(`${apiUrl}?id_opd=${selectedOpdId}`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            }
        })
        .then(response => response.json())
        .then(data => {
            const messages = document.getElementById('messages');
            messages.innerHTML = ''; // Clear previous messages

            data.forEach(chat => {
                const messageDiv = document.createElement('div');
                messageDiv.classList.add('message');
                messageDiv.classList.add(chat.id_admin ? 'admin' : 'user');
                const timestamp = new Date().toLocaleTimeString(); // Current time
                messageDiv.innerHTML = `<span>${chat.id_admin ? 'Admin' : 'Pengguna'}:</span> ${chat.chat}<div class="timestamp">${timestamp}</div>`;
                messages.appendChild(messageDiv);
            });

            messages.scrollTop = messages.scrollHeight; // Scroll to bottom
        })
        .catch(error => console.error('Error loading messages:', error));
}

// Send a message
document.getElementById('sendMessage').addEventListener('click', function() {
    const messageInput = document.getElementById('messageInput');
    const messages = document.getElementById('messages');

    const message = messageInput.value.trim();

    if (message !== '' && selectedOpdId) {
        fetch(apiUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams({
                    'action': 'create',
                    'id_opd': selectedOpdId,
                    'id_admin': 1,
                    'chat': message
                })
            })
            .then(response => response.text())
            .then(data => {
                // Display message in chat
                const messageDiv = document.createElement('div');
                messageDiv.classList.add('message', 'admin');
                messageDiv.innerHTML = `<span>Admin:</span> ${message}`;
                messages.appendChild(messageDiv);
                messageInput.value = '';
                messages.scrollTop = messages.scrollHeight; // Scroll to bottom

                // Reload messages
                loadMessages();
            })
            .catch(error => console.error('Error sending message:', error));
    } else {
        console.error('ID OPD not found.');
    }
});

// Load OPD list when clicking the chat button
document.querySelector('.chat-button').addEventListener('click', function() {
    loadOpdList();
});

document.addEventListener('DOMContentLoaded', loadMessages);

// Poll for new messages every 3 seconds
setInterval(loadMessages, 3000);
</script>

<style>
        .custom-logo {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 46px;
            height: 42px;
            border-radius: 1% 1% 35% 35%;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.5);
            margin-right: 10px;
            background-color: #fff;
            transition: transform 0.3s ease-in-out;
        }
        .custom-logo img {
            max-width: 100%;
            height: auto;
            transition: transform 0.3s ease-in-out;
        }
        .custom-logo:hover img {
            transform: rotate(360deg);
        }
        .navbar-nav .nav-item .nav-link {
            color: white;
        }
        .navbar {
            height: 65px;
        }
        .navbar-brand span {
            font-size: 18px;
            margin-bottom: 0;
            font-weight: 600;
            color: white;
        }
        .navbar, .header {
            background-color: #007bff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.5);
        }
        body {
            font-family: 'Roboto', Arial, sans-serif;
            font-size: 1rem;
            color: inherit;
        }
        .bi-list.toggle-sidebar-btn {
            color: white;
        }
        .chat-button {
            position: fixed;
            bottom: 20px;
            right: 20px;
            z-index: 1000;
        }
        .modal-dialog {
            max-width: 600px;
        }
        .chat-container {
            display: flex;
            flex-direction: column;
            height: 400px;
            overflow: hidden;
            background-color: #f0f0f0;
        }
        .messages {
            flex: 1;
            overflow-y: auto;
            padding: 10px;
            background-color: #e5ddd5;
        }
        .message {
            margin-bottom: 10px;
            padding: 10px;
            border-radius: 10px;
            background-color: #fff;
            position: relative;
            max-width: 70%;
        }
        .message.admin {
            background-color: #dcf8c6;
            align-self: flex-end;
        }
        .message.user {
            background-color: #ffffff;
            align-self: flex-start;
        }
        .message span {
            font-weight: bold;
        }
        .message .timestamp {
            font-size: 0.75rem;
            color: #999;
            position: absolute;
            bottom: 5px;
            right: 10px;
        }
        .input-container {
            display: flex;
            flex-direction: column;
            padding: 10px;
            background-color: #fff;
            border-top: 1px solid #ddd;
        }
        #messageInput {
            resize: none;
        }
        .modal-header {
            background-color: #007bff;
            color: #fff;
        }
        .modal-footer {
            background-color: #f1f1f1;
        }
        #opdList {
            text-decoration: none;
        }
        .opd-list {
    display: flex;
    flex-direction: column;
    gap: 10px;
    max-height: 400px; /* Limit height and make the list scrollable */
    overflow-y: auto;
    padding-right: 10px;
}

.chat-item {
    display: flex;
    align-items: center;
    padding: 10px;
    border-bottom: 1px solid #e0e0e0;
    cursor: pointer;
    transition: background-color 0.2s;
}

.chat-item:hover {
    background-color: #f1f1f1;
}

.chat-avatar {
    width: 40px;
    height: 40px;
    background-color: #007bff;
    color: #fff;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 18px;
    margin-right: 15px;
    font-weight: bold;
}

.chat-details {
    flex: 1;
}

.chat-name {
    margin: 0;
    font-size: 16px;
    color: #333;
    font-weight: bold;
}

.chat-last-message {
    margin-top: 5px;
    font-size: 14px;
    color: #666;
}

    </style>
</body>
</html>
