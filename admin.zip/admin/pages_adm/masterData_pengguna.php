<main id="main" class="main">
    <div class="pagetitle">
        <h1>Master Data</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php?page=masterData">Home</a></li>
                <li class="breadcrumb-item"><a href="index.php?page=masterData">Master Data</a></li>
                <li class="breadcrumb-item active">Kelola Pengguna</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <div id="data-container" class="container mt-4">
        <!-- Loading Spinner -->
        <div id="loading-spinner" class="d-flex justify-content-center my-5">
            <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
        </div>
    </div>

    <!-- Edit Modal -->
    <div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-dark text-white">
                    <h5 class="modal-title" id="editModalLabel">Edit Data</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="edit-form">
                        <input type="hidden" name="id" id="modal-id" />
                        <div class="row g-3">
                            <!-- Form Fields -->
                            <div class="col-md-6">
                                <label for="modal-nama_pengguna" class="form-label">Nama:</label>
                                <input type="text" id="modal-nama_pengguna" name="nama_pengguna" class="form-control" required />
                            </div>
                            <div class="col-md-6">
                                <label for="modal-pass_pengguna" class="form-label">Password:</label>
                                <input type="password" id="modal-pass_pengguna" name="pass_pengguna" class="form-control" required />
                            </div>
                            <div class="col-md-6">
                                <label for="modal-email" class="form-label">Email:</label>
                                <input type="email" id="modal-email" name="email" class="form-control" required />
                            </div>
                            <div class="col-md-6">
                                <label for="modal-profesi" class="form-label">Profesi:</label>
                                <input type="text" id="modal-profesi" name="profesi" class="form-control" required />
                            </div>
                            <div class="col-md-6">
                                <label for="modal-nik" class="form-label">NIK:</label>
                                <input type="text" id="modal-nik" name="nik" class="form-control" required />
                            </div>
                            <div class="col-md-6">
                                <label for="modal-tempat_lahir" class="form-label">Tempat Lahir:</label>
                                <input type="text" id="modal-tempat_lahir" name="tempat_lahir" class="form-control" required />
                            </div>
                            <div class="col-md-6">
                                <label for="modal-tgl_lahir" class="form-label">Tanggal Lahir:</label>
                                <input type="date" id="modal-tgl_lahir" name="tgl_lahir" class="form-control" required />
                            </div>
                            <div class="col-md-6">
                                <label for="modal-alamat" class="form-label">Alamat:</label>
                                <input type="text" id="modal-alamat" name="alamat" class="form-control" required />
                            </div>
                            <div class="col-md-6">
                                <label for="modal-agama" class="form-label">Agama:</label>
                                <input type="text" id="modal-agama" name="agama" class="form-control" required />
                            </div>
                            <div class="col-md-6">
                                <label for="modal-no_hp" class="form-label">No HP:</label>
                                <input type="text" id="modal-no_hp" name="no_hp" class="form-control" required />
                            </div>
                        </div>
                        <div class="modal-footer mt-4">
                            <button type="submit" class="btn btn-success">Save</button>
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', () => {
        fetchData();
    });

    async function fetchData() {
        const dataContainer = document.getElementById('data-container');
        const loadingSpinner = document.getElementById('loading-spinner');

        try {
            const response = await fetch('http://192.168.10.6:8080/Kominfo/service-sijunjung/public/Client.php', {
                method: 'GET'
            });

            if (response.ok) {
                const data = await response.json();
                displayData(data);
            } else {
                dataContainer.innerHTML = `<div class="alert alert-danger" role="alert">
                    Failed to load data. Status: ${response.status}
                </div>`;
            }
        } catch (error) {
            dataContainer.innerHTML = `<div class="alert alert-danger" role="alert">
                An error occurred: ${error.message}
            </div>`;
        } finally {
            loadingSpinner.style.display = 'none';
        }
    }

    function displayData(data) {
        const container = document.getElementById('data-container');
        container.innerHTML = ''; // Clear any existing content

        if (Array.isArray(data) && data.length > 0) {
            // Create card for better styling
            const card = document.createElement('div');
            card.className = 'card';

            const cardBody = document.createElement('div');
            cardBody.className = 'card-body';

            // Optional: Add a title or action buttons here
            const table = document.createElement('table');
            table.className = 'table table-striped table-hover table-responsive align-middle';

            const thead = document.createElement('thead');
            const tbody = document.createElement('tbody');

            const headers = ['Nama', 'Email', 'Profesi', 'NIK', 'Tempat Lahir', 'Tanggal Lahir', 'Alamat', 'Agama', 'No HP', 'Action'];
            const headerRow = document.createElement('tr');
            headers.forEach(header => {
                const th = document.createElement('th');
                th.scope = 'col';
                th.textContent = header;
                headerRow.appendChild(th);
            });
            thead.appendChild(headerRow);

            data.forEach(item => {
                const row = document.createElement('tr');

                row.appendChild(createTableCell(item.nama_pengguna));
                row.appendChild(createTableCell(item.email));
                row.appendChild(createTableCell(item.profesi));
                row.appendChild(createTableCell(item.nik));
                row.appendChild(createTableCell(item.tempat_lahir));
                row.appendChild(createTableCell(formatDate(item.tgl_lahir)));
                row.appendChild(createTableCell(item.alamat));
                row.appendChild(createTableCell(item.agama));
                row.appendChild(createTableCell(item.no_hp));

                const actionTd = document.createElement('td');

                // Edit Button
                const editButton = document.createElement('button');
                editButton.className = 'btn btn-outline-primary btn-sm me-2';
                editButton.innerHTML = '<i class="bi bi-pencil-square"></i> ';
                editButton.addEventListener('click', () => showEditForm(item));
                actionTd.appendChild(editButton);

                // Delete Button
                const deleteButton = document.createElement('button');
                deleteButton.className = 'btn btn-outline-danger btn-sm';
                deleteButton.innerHTML = '<i class="bi bi-trash"></i> ';
                deleteButton.addEventListener('click', () => deleteAccount(item.id));
                actionTd.appendChild(deleteButton);

                row.appendChild(actionTd);
                tbody.appendChild(row);
            });

            table.appendChild(thead);
            table.appendChild(tbody);
            cardBody.appendChild(table);
            card.appendChild(cardBody);
            container.appendChild(card);
        } else {
            container.innerHTML = `<div class="alert alert-info" role="alert">
                No data available.
            </div>`;
        }
    }

    function createTableCell(content) {
        const td = document.createElement('td');
        td.textContent = content || '-';
        return td;
    }

    function formatDate(dateStr) {
        if (!dateStr) return '-';
        const options = { year: 'numeric', month: 'long', day: 'numeric' };
        const date = new Date(dateStr);
        return date.toLocaleDateString(undefined, options);
    }

    function showEditForm(item) {
        // Populate the form fields with the item's data
        document.getElementById('modal-id').value = item.id;
        document.getElementById('modal-nama_pengguna').value = item.nama_pengguna;
        document.getElementById('modal-pass_pengguna').value = item.pass_pengguna;
        document.getElementById('modal-email').value = item.email;
        document.getElementById('modal-profesi').value = item.profesi;
        document.getElementById('modal-nik').value = item.nik;
        document.getElementById('modal-tempat_lahir').value = item.tempat_lahir;
        document.getElementById('modal-tgl_lahir').value = item.tgl_lahir;
        document.getElementById('modal-alamat').value = item.alamat;
        document.getElementById('modal-agama').value = item.agama;
        document.getElementById('modal-no_hp').value = item.no_hp;

        // Show the modal
        const editModal = new bootstrap.Modal(document.getElementById('editModal'));
        editModal.show();

        // Handle form submission
        const form = document.getElementById('edit-form');
        form.onsubmit = async function (event) {
            event.preventDefault();

            const formData = new FormData(form);
            const data = Object.fromEntries(formData.entries());

            try {
                const response = await fetch('http://192.168.10.6:8080/Kominfo/service-sijunjung/public/Client.php', {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: new URLSearchParams(data).toString()
                });

                if (response.ok) {
                    alert('Data updated successfully');
                    location.reload(); // Refresh the page to show updated data
                } else {
                    const errorText = await response.text();
                    alert(`Failed to update data. Server responded with: ${errorText}`);
                }
            } catch (error) {
                alert('An error occurred: ' + error.message);
            }
        };
    }

    async function deleteAccount(id) {
        if (confirm('Are you sure you want to delete this account?')) {
            try {
                const response = await fetch(`http://192.168.10.6:8080/Kominfo/service-sijunjung/public/Client.php`, {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: new URLSearchParams({ id }).toString()
                });

                if (response.ok) {
                    alert('Account deleted successfully');
                    location.reload(); // Refresh the page to reflect deletion
                } else {
                    const errorText = await response.text();
                    alert(`Failed to delete account. Server responded with: ${errorText}`);
                }
            } catch (error) {
                alert('An error occurred: ' + error.message);
            }
        }
    }
    </script>
</main>
