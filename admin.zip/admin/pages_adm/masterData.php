<main id="main" class="main">

    <div class="pagetitle">
        <h1>Master Data</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php?page=masterData">Home</a></li>
                <li class="breadcrumb-item active">Master Data</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
        <div class="row justify-content-center">

            <!-- Modern Dashboard Menu -->
            <div class="col-12 mb-4">
                <div class="menu-container">
                    <div class="menu-item animate-menu" data-aos="fade-right" data-aos-delay="100">
                        <div class="icon">
                            <i class="bi bi-person-circle fs-2 text-primary"></i>
                        </div>
                        <h5 class="menu-title">Operator</h5>
                        <a href="index.php?page=masterData_op" class="stretched-link"></a>
                    </div>
                    <div class="menu-item animate-menu" data-aos="fade-right" data-aos-delay="200">
                        <div class="icon">
                            <i class="bi bi-people fs-2 text-success"></i>
                        </div>
                        <h5 class="menu-title">Pengguna</h5>
                        <a href="index.php?page=masterData_pengguna" class="stretched-link"></a>
                    </div>
                    <div class="menu-item animate-menu" data-aos="fade-right" data-aos-delay="400">
                        <div class="icon">
                            <i class="bi bi-building fs-2 text-warning"></i>
                        </div>
                        <h5 class="menu-title">OPD</h5>
                        <a href="index.php?page=masterData_opd" class="stretched-link"></a>
                    </div>
                    <div class="menu-item animate-menu" data-aos="fade-right" data-aos-delay="500">
                        <div class="icon">
                            <i class="bi bi-headset fs-2 text-info"></i>
                        </div>
                        <h5 class="menu-title">Layanan</h5>
                        <a href="index.php?page=masterData_layanan" class="stretched-link"></a>
                    </div>
                </div>
            </div><!-- End Modern Dashboard Menu -->

        </div>

</main><!-- End Main -->

<!-- AOS (Animate on Scroll) Library for Animations -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
<script>
    AOS.init({
        duration: 1000,
        easing: 'ease-in-out',
        once: true
    });
</script>

<style>
    .menu-container {
    display: flex;
    justify-content: flex-start; /* Ubah dari space-between menjadi flex-start */
    flex-wrap: wrap;
    gap: 20px; /* Opsional: Menambahkan sedikit jarak antar item */
}

.menu-item {
    background: (135deg, #ffffff, #f0f0f0);
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.15);
    border-radius: 20px;
    padding: 10px;
    text-align: center;
    width: 18%;
    position: relative;
    overflow: hidden;
    cursor: pointer;
    transition: transform 0.4s ease-in-out, background 0.4s ease-in-out, box-shadow 0.4s ease-in-out;
}

.menu-item:hover {
    transform: translateY(-10px);
    background: linear-gradient(135deg, #ebedee, #d9d9d9);
    box-shadow: 0 6px 15px rgba(0, 0, 0, 0.2);
}

.icon {
    margin-bottom: 5px;
}

.menu-title {
    font-weight: 600;
    font-size: 1.2rem;
    color: #333;
}

.stretched-link::after {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: 1;
}

@media (max-width: 992px) {
    .menu-item {
        width: 45%;
        margin-bottom: 20px;
    }
}

@media (max-width: 576px) {
    .menu-item {
        width: 100%;
        margin-bottom: 20px;
    }
}
</style>
