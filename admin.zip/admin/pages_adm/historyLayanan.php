<main id="main" class="main">
    <div class="pagetitle">
        <h1>History</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                <li class="breadcrumb-item active">History Layanan</li>
            </ol>
        </nav>
    </div>

    
    <div class="card">
        <div class="card-body">
        <h5 class="card-title p-3 bg-light border rounded d-inline-block w-auto">Daftar History Layanan</h5>
                <div class="table-responsive p-3 border rounded">
                    <table id="tiketTable" class="table table-hover">
                        <thead class="thead-dark">
                            <tr>
                                <th>No</th> <!-- New column for row numbers -->
                                <th>Pengguna</th>
                                <th>Layanan</th>
                                <th>Nama OPD</th>
                                <th>Email</th>
                                <th>Keterangan</th>
                                <th>Status</th>
                                <th>Waktu</th>
                                <th>Lampiran</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!-- Data will be loaded here using JavaScript -->
                        </tbody>
                    </table>
                </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.3.3/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            loadData();

            document.getElementById('updateForm').addEventListener('submit', (event) => {
                event.preventDefault();
                updateProcess();
            });
        });

        function loadData() {
            fetch('http://192.168.10.6:8080/Kominfo/service-sijunjung/public/Tiket.php?action=tiketdetails')
                .then(response => response.json())
                .then(data => {
                    console.log('Data from API:', data);
                    const tbody = document.querySelector('#tiketTable tbody');

                    if (!data || data.length === 0) {
                        tbody.innerHTML = '<tr><td colspan="10" class="text-center">No data available.</td></tr>';
                        return;
                    }

                    tbody.innerHTML = data.map((tiket, index) => {
                        let statusClass = '';
                        switch (tiket.ket_proses.toLowerCase()) {
                            case 'selesai':
                                statusClass = 'table-success';
                                break;
                            case 'diajukan':
                                statusClass = 'table-warning';
                                break;
                            case 'diproses':
                                statusClass = 'table-info';
                                break;
                            case 'dibatalkan':
                                statusClass = 'table-danger';
                                break;
                            default:
                                statusClass = '';
                        }

                        return `
                        <tr class="${statusClass}">
                            <td>${index + 1}</td> <!-- Row number -->
                            <td>${tiket.nama_pengguna || 'Not available'}</td>
                            <td>${tiket.nama_layanan || 'Not available'}</td>
                            <td>${tiket.nama_opd || 'Not available'}</td>
                            <td>${tiket.email || 'Not available'}</td>
                            <td>${tiket.keterangan || 'Not available'}</td>
                            <td>${tiket.ket_proses || 'Not available'}</td>
                            <td>${tiket.tgl_diajukan || 'Not available'}</td>
                            <td>${tiket.lampiran && tiket.lampiran.length > 0 ? `
                                <div class="attachments">
                                    <ul class="list-unstyled mb-0">
                                        ${tiket.lampiran.map(lampiran => `
                                            <li><a href="http://192.168.10.6:8080/Kominfo/service-sijunjung/public/Document.php?filename=${encodeURIComponent(lampiran)}" target="_blank" class="text-decoration-none">${lampiran}</a></li>
                                        `).join('')}
                                    </ul>
                                </div>
                            ` : '<p class="text-muted mb-0">Kosong</p>'}</td>
                        </tr>
                        `;
                    }).join('');
                })
                .catch(error => {
                    console.error('Error:', error);
                    document.querySelector('#tiketTable tbody').innerHTML =
                        '<tr><td colspan="10" class="text-center text-danger">Error loading data.</td></tr>';
                });
        }
    </script>
</main>
