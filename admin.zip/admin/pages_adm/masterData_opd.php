<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.min.js"></script>


<main id="main" class="main">

    <div class="pagetitle">
        <h1>Master Data</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php?page=masterData">Home</a></li>
                <li class="breadcrumb-item"><a href="index.php?page=masterData">Master Data</a></li>
                <li class="breadcrumb-item active">Kelola OPD</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <div class="container">
        <button id="openModalBtn" class="btn btn-primary">Tambahkan OPD</button>

        <!-- Modal -->
        <div id="opdModal" class="modal" style="display:none;">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="opdModalLabel">Tambah Data OPD</h5>
                        <button type="button" class="btn-close" id="closeModalBtn"></button>
                    </div>
                    <div class="modal-body">
                        <form id="opdForm" enctype="multipart/form-data">
                            <!-- Form fields -->
                            <div class="mb-3">
                                <label for="nama_opd" class="form-label">Nama OPD</label>
                                <input type="text" class="form-control" id="nama_opd" name="nama_opd" required>
                            </div>
                            <div class="mb-3">
                                <label for="logo_opd" class="form-label">Logo OPD</label>
                                <input type="file" class="form-control" id="logo_opd" name="logo_opd" accept=".jpeg, .jpg, .png, .gif, .bmp, .tiff, .tif, .webp, .svg">
                            </div>
                            <div class="mb-3">
                                <label for="deskripsi" class="form-label">Deskripsi</label>
                                <textarea class="form-control" id="deskripsi" name="deskripsi" rows="4" required></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="alamat_opd" class="form-label">Alamat OPD</label>
                                <input type="text" class="form-control" id="alamat_opd" name="alamat_opd" required>
                            </div>
                            <div class="mb-3">
                                <label for="no_telp" class="form-label">No. Telepon</label>
                                <input type="tel" class="form-control" id="no_telp" name="no_telp" required>
                            </div>
                            <div class="mb-3">
                                <label for="email_opd" class="form-label">Email OPD</label>
                                <input type="email" class="form-control" id="email_opd" name="email_opd" required>
                            </div>
                            <div class="mb-3">
                                <label for="visi" class="form-label">Visi</label>
                                <textarea class="form-control" id="visi" name="visi" rows="2" required></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="misi" class="form-label">Misi</label>
                                <textarea class="form-control" id="misi" name="misi" rows="2" required></textarea>
                            </div>
                            <div class="text-end">
                                <button type="submit" class="btn btn-success">Tambah Data</button>
                            </div>
                        </form>
                        <div id="alert" class="alert mt-3" style="display: none;"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- CRUD opd Account -->

    <div class="card mt-3">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped" id="opdTable">
                    <thead>
                        <tr>
                            <th>Nama OPD</th>
                            <th>Logo</th>
                            <th>Deskripsi</th>
                            <th>Alamat</th>
                            <th>Nomor</th>
                            <th>Email</th>
                            <th>Visi</th>
                            <th>Misi</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody id="opdTableBody">
                        <!-- Dynamic rows will be appended here by JavaScript -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Update Opd Modal -->
    <div class="modal fade" id="updateOpdModal" tabindex="-1" aria-labelledby="updateOpdModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="updateOpdModalLabel">Update OPD</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="updateOpdForm" enctype="multipart/form-data">
                        <input type="hidden" id="updateOpdId">
                        <div class="mb-3">
                            <label for="updateOpdName" class="form-label">Nama OPD</label>
                            <input type="text" class="form-control" id="updateOpdName" required>
                        </div>
                        <div class="mb-3">
                            <label for="updateLogoOpd" class="form-label">Logo OPD</label>
                            <input type="file" class="form-control" id="updateLogoOpd" name="updateLogoOpd" accept=".jpeg, .jpg, .png, .gif, .bmp, .tiff, .tif, .webp, .svg">
                        </div>
                        <div class="mb-3">
                            <label for="updateDeskripsi" class="form-label">Deskripsi</label>
                            <textarea class="form-control" id="updateDeskripsi" rows="4" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="updateAlamat" class="form-label">Alamat OPD</label>
                            <input type="text" class="form-control" id="updateAlamat" required>
                        </div>
                        <div class="mb-3">
                            <label for="updateNoTelp" class="form-label">No. Telepon</label>
                            <input type="tel" class="form-control" id="updateNoTelp" required>
                        </div>
                        <div class="mb-3">
                            <label for="updateEmail" class="form-label">Email OPD</label>
                            <input type="email" class="form-control" id="updateEmail" required>
                        </div>
                        <div class="mb-3">
                            <label for="updateVisi" class="form-label">Visi</label>
                            <textarea class="form-control" id="updateVisi" rows="2" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="updateMisi" class="form-label">Misi</label>
                            <textarea class="form-control" id="updateMisi" rows="2" required></textarea>
                        </div>
                        <div class="text-end">
                            <button type="submit" class="btn btn-primary">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <script>
        // fetching data
        document.addEventListener('DOMContentLoaded', async function() {
    await fetchOpd();

    document.getElementById('updateOpdForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        await updateOpd();
    });

});

        async function fetchOpd() {
    try {
        const response = await fetch('http://192.168.10.6:8080/Kominfo/service-sijunjung/public/Opd.php');
        const data = await response.json();
        const tbody = document.getElementById('opdTableBody');
        tbody.innerHTML = '';
        data.forEach(opd => {
            const logoUrl = `http://192.168.10.6:8080/Kominfo/service-sijunjung/public/images.php?filename=${encodeURIComponent(opd.logo_opd || 'default-image.jpg')}`;

            const row = `
                <tr>
                    <td>${opd.nama_opd}</td>
                    <td>
                        <img class="card-img-top" src="${logoUrl}" alt="Logo OPD" style="width: 100px; height: auto;">
                    </td>
                    <td>${opd.deskripsi}</td>
                    <td>${opd.alamat_opd}</td>
                    <td>${opd.no_telp}</td>
                    <td>${opd.email_opd}</td>
                    <td>${opd.visi}</td>
                    <td>${opd.misi}</td>
                    <td>
                        <button class="btn btn-warning btn-sm" onclick="editOpd('${opd.id_opd}', '${opd.nama_opd}', '${opd.logo_opd}', '${opd.deskripsi}', '${opd.alamat_opd}', '${opd.no_telp}', '${opd.email_opd}', '${opd.visi}', '${opd.misi}')">Edit</button>
                        <button class="btn btn-danger btn-sm" onclick="deleteOpd(${opd.id_opd})">Delete</button>
                    </td>
                </tr>
            `;
            tbody.insertAdjacentHTML('beforeend', row);
        });
    } catch (error) {
        console.error('Error fetching operators:', error);
    }
}

// update opd modal

// Populate the modal with existing data for editing
function editOpd(id_opd, nama_opd, logo_opd, deskripsi, alamat_opd, no_telp, email_opd, visi, misi) {
            document.getElementById('updateOpdId').value = id_opd;
            document.getElementById('updateOpdName').value = nama_opd;
            document.getElementById('updateDeskripsi').value = deskripsi;
            document.getElementById('updateAlamat').value = alamat_opd;
            document.getElementById('updateNoTelp').value = no_telp;
            document.getElementById('updateEmail').value = email_opd;
            document.getElementById('updateVisi').value = visi;
            document.getElementById('updateMisi').value = misi;

            // Show the modal
            new bootstrap.Modal(document.getElementById('updateOpdModal')).show();
        }

        // Handle the update submission
        async function updateOpd() {
            const id_opd = document.getElementById('updateOpdId').value;
            const nama_opd = document.getElementById('updateOpdName').value;
            const logo_opd = document.getElementById('updateLogoOpd').files[0];
            const deskripsi = document.getElementById('updateDeskripsi').value;
            const alamat_opd = document.getElementById('updateAlamat').value;
            const no_telp = document.getElementById('updateNoTelp').value;
            const email_opd = document.getElementById('updateEmail').value;
            const visi = document.getElementById('updateVisi').value;
            const misi = document.getElementById('updateMisi').value;

            try {
                const response = await fetch(`http://192.168.10.6:8080/Kominfo/service-sijunjung/public/Opd.php`, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: new URLSearchParams({ id_opd, nama_opd, logo_opd, deskripsi, alamat_opd, no_telp, email_opd, visi, misi })
                });
                
                const data = await response.json();
        if (data.success) {
            alert('Opd updated successfully!');
        } else {
            alert('Error updating operator: ' + data.message);
        }
        bootstrap.Modal.getInstance(document.getElementById('updateOpdModal')).hide();
        await fetchOpd();
    } catch (error) {
        console.error('Error updating opd:', error);
    }
}



// delete opd

async function deleteOpd(id_opd) {
    if (confirm('Are you sure you want to delete this opd?')) {
        try {
            const response = await fetch('http://192.168.10.6:8080/Kominfo/service-sijunjung/public/Opd.php', {
                method: 'DELETE',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({ id_opd })
            });
            const data = await response.json();
            if (data.success) {
                alert('Operator deleted successfully!');
            } else {
                alert('Error deleting opd: ' + data.message);
            }
            await fetchOpd();
        } catch (error) {
            console.error('Error deleting opd:', error);
        }
    }
}

       // Open modal
var openModalBtn = document.getElementById("openModalBtn");
var opdModal = new bootstrap.Modal(document.getElementById('opdModal'));

openModalBtn.onclick = function() {
    opdModal.show();
}

document.getElementById('opdForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the form from submitting the default way

    var formData = new FormData(document.getElementById('opdForm'));
    formData.append('action', 'create'); // Add action parameter

    fetch('http://192.168.10.6:8080/Kominfo/service-sijunjung/public/Opd.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text()) // Change to response.text() to inspect the raw response
    .then(result => {
        try {
            var jsonResult = JSON.parse(result); // Parse response manually
            var alert = document.getElementById('alert');
            if (jsonResult.message === "OPD created successfully") {
                alert.textContent = 'Data berhasil ditambahkan!';
                alert.className = 'alert alert-success';
            } else {
                alert.textContent = 'Terjadi kesalahan: ' + jsonResult.message;
                alert.className = 'alert alert-danger';
            }
            alert.style.display = 'block';
        } catch (error) {
            var alert = document.getElementById('alert');
            alert.textContent = 'Terjadi kesalahan dalam parsing JSON: ' + error.message;
            alert.className = 'alert alert-danger';
            alert.style.display = 'block';
        }
    })
    .catch(error => {
        var alert = document.getElementById('alert');
        alert.textContent = 'Terjadi kesalahan: ' + error.message;
        alert.className = 'alert alert-danger';
        alert.style.display = 'block';
    })
    .finally(() => {
        // Refresh the page after 3 seconds
        setTimeout(function() {
            location.reload();
        }, 1000); // Adjust the timeout duration as needed
    });
});

    </script>
        
</main><!-- End #main -->

