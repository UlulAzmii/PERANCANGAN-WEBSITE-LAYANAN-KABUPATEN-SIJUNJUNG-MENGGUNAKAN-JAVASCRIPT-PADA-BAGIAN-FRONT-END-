<head>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
</head>

<main id="main" class="main">

    <div class="pagetitle">
        <h1>Master Data</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php?page=masterData">Home</a></li>
                <li class="breadcrumb-item"><a href="index.php?page=masterData">Master Data</a></li>
                <li class="breadcrumb-item active">Kelola layanan</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <div class="d-flex">
        <button class="btn btn-primary me-2" data-bs-toggle="modal" data-bs-target="#createLayananModal" onclick="fetchOpds()">Create Layanan</button>
    </div>

    <!-- Create Layanan Modal -->
    <div class="modal fade" id="createLayananModal" tabindex="-1" aria-labelledby="createLayananModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="createLayananModalLabel">Create Layanan</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="createLayananForm">
                        <div class="mb-3">
                            <label for="createLayananName" class="form-label">Nama Layanan</label>
                            <input type="text" class="form-control" id="createLayananName" required>
                        </div>
                        <div class="mb-3">
                            <label for="createSyarat" class="form-label">Syarat</label>
                            <input type="text" class="form-control" id="createSyarat" required>
                        </div>
                        <div class="mb-3">
                            <label for="createLayananOpd" class="form-label">OPD</label>
                            <select class="form-control" id="createLayananOpd" required style="width: 100%;">
                                <!-- OPD options will be dynamically loaded here -->
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary">Create</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Edit Layanan Modal -->
    <div class="modal fade" id="editLayananModal" tabindex="-1" aria-labelledby="editLayananModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editLayananModalLabel">Edit Layanan</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="editLayananForm">
                        <input type="hidden" id="editLayananId">
                        <div class="mb-3">
                            <label for="editLayananName" class="form-label">Nama Layanan</label>
                            <input type="text" class="form-control" id="editLayananName" required>
                        </div>
                        <div class="mb-3">
                            <label for="editSyarat" class="form-label">Syarat</label>
                            <input type="text" class="form-control" id="editSyarat" required>
                        </div>
                        <div class="mb-3">
                            <label for="editLayananOpd" class="form-label">OPD</label>
                            <select class="form-control" id="editLayananOpd" required style="width: 100%;">
                                <!-- OPD options will be dynamically loaded here -->
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary">Update</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Layanan Table -->
    <div class="table-responsive mt-3">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Nama Layanan</th>
                    <th>Syarat</th>
                    <th>OPD</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody id="layananTableBody">
                <!-- Layanan rows will be dynamically loaded here -->
            </tbody>
        </table>
    </div>

    <script>
        let opds = [];

async function fetchOpds() {
    try {
        const response = await fetch('http://192.168.10.6:8080/Kominfo/service-sijunjung/public/Opd.php');
        opds = await response.json();
        console.log('OPDs fetched:', opds); // Debugging line

        // Populate dropdowns with OPD options
        populateOpdSelects(opds);
    } catch (error) {
        console.error('Error fetching OPDs:', error);
    }
}

function populateOpdSelects(opds) {
    const createOpdSelect = document.getElementById('createLayananOpd');
    const editOpdSelect = document.getElementById('editLayananOpd');

    // Clear existing options
    createOpdSelect.innerHTML = '';
    editOpdSelect.innerHTML = '';

    // Populate options
    opds.forEach(opd => {
        const option = `<option value="${opd.id_opd}">${opd.nama_opd}</option>`;
        createOpdSelect.insertAdjacentHTML('beforeend', option);
        editOpdSelect.insertAdjacentHTML('beforeend', option);
    });

    // Initialize Select2 for searchable dropdown
    $('#createLayananOpd').select2({ dropdownParent: $('#createLayananModal') });
    $('#editLayananOpd').select2({ dropdownParent: $('#editLayananModal') });
}

async function fetchLayanan() {
    try {
        // Ensure OPDs are loaded before fetching layanan data
        if (opds.length === 0) {
            await fetchOpds();
        }

        const response = await fetch('http://192.168.10.6:8080/Kominfo/service-sijunjung/public/Layanan.php');
        const layananData = await response.json();
        console.log('Layanan data fetched:', layananData); // Debugging line

        populateLayananTable(layananData);
    } catch (error) {
        console.error('Error fetching layanan:', error);
        fetchLayanan();
    }
}

function populateLayananTable(layananData) {
    const tableBody = document.getElementById('layananTableBody');
    tableBody.innerHTML = ''; // Clear existing rows

    layananData.forEach(layanan => {
        const opd = opds.find(opd => opd.id_opd === layanan.id_opd);
        const nama_opd = opd ? opd.nama_opd : 'Unknown OPD';
        const row = `
            <tr>
                <td>${layanan.nama_layanan}</td>
                <td>${layanan.syarat}</td>
                <td>${nama_opd}</td>
                <td>
                    <button class="btn btn-sm btn-warning" onclick="editLayanan(${layanan.id_layanan}, '${layanan.nama_layanan}', '${layanan.syarat}', '${layanan.id_opd}')">Edit</button>
                    <button class="btn btn-sm btn-danger" onclick="deleteLayanan(${layanan.id_layanan})">Delete</button>
                </td>
            </tr>
        `;
        tableBody.insertAdjacentHTML('beforeend', row);
    });
}

document.getElementById('createLayananForm').addEventListener('submit', async function(event) {
    event.preventDefault();

    const nama_layanan = document.getElementById('createLayananName').value;
    const syarat = document.getElementById('createSyarat').value;
    const id_opd = document.getElementById('createLayananOpd').value;

    try {
        const response = await fetch('http://192.168.10.6:8080/Kominfo/service-sijunjung/public/Layanan.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({ action: 'create', nama_layanan, syarat, id_opd })
        });
        const data = await response.json();
        if (data.success) {
            alert('Layanan created successfully!');
            document.getElementById('createLayananForm').reset();
            fetchLayanan();
        } else {
            alert('Error creating layanan: ' + data.message);
            fetchLayanan();
        }
        $('#createLayananModal').modal('hide');
    } catch (error) {
        console.error('Error creating layanan:', error);
        fetchLayanan();
    }
});

function editLayanan(id_layanan, nama_layanan, syarat, id_opd) {
    document.getElementById('editLayananId').value = id_layanan;
    document.getElementById('editLayananName').value = nama_layanan;
    document.getElementById('editSyarat').value = syarat;
    document.getElementById('editLayananOpd').value = id_opd;

    $('#editLayananModal').modal('show');
}

document.getElementById('editLayananForm').addEventListener('submit', async function(event) {
    event.preventDefault();

    const id_layanan = document.getElementById('editLayananId').value;
    const nama_layanan = document.getElementById('editLayananName').value;
    const syarat = document.getElementById('editSyarat').value;
    const id_opd = document.getElementById('editLayananOpd').value;

    try {
        const response = await fetch('http://192.168.10.6:8080/Kominfo/service-sijunjung/public/Layanan.php', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({ id_layanan, nama_layanan, syarat, id_opd })
        });
        const data = await response.json();
        if (data.success) {
            alert('Layanan updated successfully!');
            fetchLayanan();
        } else {
            alert('Error updating layanan: ' + data.message);
            fetchLayanan();
        }
        $('#editLayananModal').modal('hide');
    } catch (error) {
        console.error('Error updating layanan:', error);
        fetchLayanan();
    }
});

async function deleteLayanan(id_layanan) {
    if (confirm('Are you sure you want to delete this layanan?')) {
        try {
            const response = await fetch('http://192.168.10.6:8080/Kominfo/service-sijunjung/public/Layanan.php', {
                method: 'DELETE',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({ id_layanan })
            });
            const data = await response.json();
            if (data.success) {
                alert('Layanan deleted successfully!');
                fetchLayanan();
            } else {
                alert('Error deleting layanan: ' + data.message);
                fetchLayanan();
            }
        } catch (error) {
            console.error('Error deleting layanan:', error);
            fetchLayanan();
        }
    }
}

document.addEventListener('DOMContentLoaded', () => {
    fetchLayanan(); // Fetch layanan data to populate the table
});
    </script>

</main>

