<main id="main" class="main">
    <div class="pagetitle">
        <h1>Laporan</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                <li class="breadcrumb-item active">Laporan</li>
            </ol>
        </nav>
    </div>

    <div class="card">
        <div class="card-body">
                <h5 class="card-title p-3 bg-light border rounded d-inline-block w-auto" >Daftar Laporan</h5>
                <div class="table-responsive p-3 border rounded">
                    <table id="tiketTable" class="table table-hover table-striped">
                        <thead class="thead-dark">
                            <tr>
                                <th>No</th> <!-- Kolom nomor urut -->
                                <th>Pengguna</th>
                                <th>Layanan</th>
                                <th>Nama OPD</th>
                                <th>Email</th>
                                <th>Keterangan</th>
                                <th>Status</th>
                                <th>Waktu</th>
                                <th>Lampiran</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!-- Data will be loaded here via JavaScript -->
                        </tbody>
                    </table>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.3.3/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            loadData();
        });

        async function loadData() {
            try {
                const response = await fetch('http://192.168.10.6:8080/Kominfo/service-sijunjung/public/Tiket.php?action=tiketdetails');
                const data = await response.json();

                const tbody = document.querySelector('#tiketTable tbody');

                if (!response.ok || !Array.isArray(data)) {
                    throw new Error('Failed to fetch data.');
                }

                if (data.length === 0) {
                    tbody.innerHTML = '<tr><td colspan="11" class="text-center">No data available.</td></tr>';
                    return;
                }

                const filteredData = data.filter(tiket => tiket.ket_proses === 'Selesai');

                if (filteredData.length === 0) {
                    tbody.innerHTML = '<tr><td colspan="11" class="text-center">No completed tickets available.</td></tr>';
                    return;
                }

                tbody.innerHTML = filteredData.map((tiket, index) => `
                    <tr class="${tiket.ket_proses === 'Selesai' ? 'table-success' : 'table-warning'}">
                        <td>${index + 1}</td> <!-- Menambahkan nomor urut -->
                        <td>${tiket.nama_pengguna || 'Not available'}</td>
                        <td>${tiket.nama_layanan || 'Not available'}</td>
                        <td>${tiket.nama_opd || 'Not available'}</td>
                        <td>${tiket.email || 'Not available'}</td>
                        <td>${tiket.keterangan || 'Not available'}</td>
                        <td>${tiket.ket_proses || 'Not available'}</td>
                        <td>${tiket.tgl_diajukan || 'Not available'}</td>
                        <td>${tiket.lampiran && tiket.lampiran.length > 0 ? `
                            <div class="attachments">
                                <ul class="list-unstyled mb-0">
                                    ${tiket.lampiran.map(lampiran => `
                                        <li><a href="http://192.168.10.6:8080/Kominfo/service-sijunjung/public/Document.php?filename=${encodeURIComponent(lampiran)}" target="_blank" class="text-decoration-none">${lampiran}</a></li>
                                    `).join('')}
                                </ul>
                            </div>
                        ` : '<p class="text-muted mb-0">Lampiran Kosong</p>'}</td>
                        <td>
                            <button class="btn btn-danger btn-sm" onclick="deleteTicket(${tiket.id_tiket})">Delete</button>
                        </td>
                    </tr>
                `).join('');
            } catch (error) {
                console.error('Error:', error);
                document.querySelector('#tiketTable tbody').innerHTML =
                    '<tr><td colspan="11" class="text-center text-danger">Error loading data.</td></tr>';
            }
        }

        async function deleteTicket(id_tiket) {
            if (confirm('Are you sure you want to delete this ticket?')) {
                try {
                    const response = await fetch('http://192.168.10.6:8080/Kominfo/service-sijunjung/public/Tiket.php', {
                        method: 'DELETE',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded'
                        },
                        body: new URLSearchParams({ id_tiket }).toString()
                    });

                    if (response.ok) {
                        alert('Ticket deleted successfully.');
                        loadData();
                    } else {
                        alert('Failed to delete the ticket.');
                    }
                } catch (error) {
                    console.error('Error:', error);
                    alert('An error occurred while deleting the ticket.');
                }
            }
        }
    </script>
</main>
