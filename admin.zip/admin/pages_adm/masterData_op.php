
<main id="main" class="main">
    <div class="pagetitle">
        <h1>Master Data</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php?page=masterData">Home</a></li>
                <li class="breadcrumb-item"><a href="index.php?page=masterData">Master Data</a></li>
                <li class="breadcrumb-item active">Kelola Operator</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <div class="container mt-4">
        <!-- Create Operator Button -->
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#createOperatorModal">Create Operator</button>

        <!-- Operator Table -->
        <div class="card mt-3">
            <div class="card-body">
                <table class="table table-striped" id="operatorTable">
                    <thead>
                        <tr>
                            <th>Nama Operator</th>
                            <th>Password</th>
                            <th>OPD</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody id="operatorTableBody">
                        <!-- Dynamic rows will be appended here by JavaScript -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Create Operator Modal -->
    <div class="modal fade" id="createOperatorModal" tabindex="-1" aria-labelledby="createOperatorModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="createOperatorModalLabel">Create Operator</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="createOperatorForm">
                        <div class="mb-3">
                            <label for="createOperatorName" class="form-label">Nama Operator</label>
                            <input type="text" class="form-control" id="createOperatorName" required>
                        </div>
                        <div class="mb-3">
                            <label for="createOperatorPass" class="form-label">Password Operator</label>
                            <input type="password" class="form-control" id="createOperatorPass" required>
                        </div>
                        <div class="mb-3">
                            <label for="createOperatorOpd" class="form-label">OPD</label>
                            <select class="form-control" id="createOperatorOpd" required>
                                <!-- OPD options will be dynamically loaded here -->
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary">Create</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Update Operator Modal -->
    <div class="modal fade" id="updateOperatorModal" tabindex="-1" aria-labelledby="updateOperatorModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="updateOperatorModalLabel">Update Operator</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="updateOperatorForm">
                        <input type="hidden" id="updateOperatorId">
                        <div class="mb-3">
                            <label for="updateOperatorName" class="form-label">Nama Operator</label>
                            <input type="text" class="form-control" id="updateOperatorName" required>
                        </div>
                        <div class="mb-3">
                            <label for="updateOperatorPass" class="form-label">Password Operator</label>
                            <input type="password" class="form-control" id="updateOperatorPass" required>
                        </div>
                        <div class="mb-3">
                            <label for="updateOperatorOpd" class="form-label">OPD</label>
                            <select class="form-control" id="updateOperatorOpd" required>
                                <!-- OPD options will be dynamically loaded here -->
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary">Update</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</main><!-- End Main -->

<!-- Include Bootstrap JS (Make sure you include it before your script) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script>
// JavaScript to handle CRUD operations

document.addEventListener('DOMContentLoaded', async function() {
    await fetchOpds();
    await fetchOperators();

    document.getElementById('createOperatorForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        await createOperator();
    });

    document.getElementById('updateOperatorForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        await updateOperator();
    });
});

const opdMap = {}; // Global map to store id_opd -> nama_opd mapping

async function fetchOperators() {
    try {
        const response = await fetch('http://192.168.10.6:8080/Kominfo/service-sijunjung/public/Operator.php');
        const data = await response.json();
        const tbody = document.getElementById('operatorTableBody');
        tbody.innerHTML = '';
        
        data.forEach((operator) => {
            const row = `
                <tr>
                    <td>${operator.nama_operator}</td>
                    <td>${operator.pass_operator}</td>
                    <td>${opdMap[operator.id_opd] || 'Unknown OPD'}</td>
                    <td>
                        <button class="btn btn-warning btn-sm" onclick="editOperator(${operator.id_operator}, '${operator.nama_operator}', '${operator.pass_operator}', ${operator.id_opd})">Edit</button>
                        <button class="btn btn-danger btn-sm" onclick="deleteOperator(${operator.id_operator})">Delete</button>
                    </td>
                </tr>
            `;
            tbody.insertAdjacentHTML('beforeend', row);
        });
    } catch (error) {
        console.error('Error fetching operators:', error);
    }
}


async function fetchOpds() {
    try {
        const response = await fetch('http://192.168.10.6:8080/Kominfo/service-sijunjung/public/Opd.php');
        const data = await response.json();
        const createOpdSelect = document.getElementById('createOperatorOpd');
        const updateOpdSelect = document.getElementById('updateOperatorOpd');

        createOpdSelect.innerHTML = '';
        updateOpdSelect.innerHTML = '';

        data.forEach(opd => {
            opdMap[opd.id_opd] = opd.nama_opd;

            const option = `<option value="${opd.id_opd}">${opd.nama_opd}</option>`;
            createOpdSelect.insertAdjacentHTML('beforeend', option);
            updateOpdSelect.insertAdjacentHTML('beforeend', option);
        });
    } catch (error) {
        console.error('Error fetching OPDs:', error);
    }
}

async function createOperator() {
    // Get input values
    const nama_operator = document.getElementById('createOperatorName').value.trim();
    const pass_operator = document.getElementById('createOperatorPass').value.trim();
    const id_opd = document.getElementById('createOperatorOpd').value.trim();

    // Check if any field is empty
    if (!nama_operator || !pass_operator || !id_opd) {
        alert('Please fill in all fields.');
        return;
    }

    // Prepare request options
    const requestOptions = {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
            action: 'create',
            nama_operator,
            pass_operator,
            id_opd,
        }),
    };

    try {
        // Make API request
        const response = await fetch('http://192.168.10.6:8080/Kominfo/service-sijunjung/public/Operator.php', requestOptions);

        // Check if the response is ok (status in the range 200-299)
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();

        if (data.success) {
            alert('Operator created successfully!');
        } else {
            alert('Error creating operator: ' + data.message);
        }

        // Close the modal
        // const modalElement = document.getElementById('createOperatorModal');
        // if (modalElement) {
        //     const modalInstance = bootstrap.Modal.getInstance(modalElement);
        //     if (modalInstance) {
        //         modalInstance.hide();
        //     }
        // }

        // Refresh the operators list
        await fetchOperators();

    } catch (error) {
        // Log error and notify the user
        console.error('Error creating operator:', error);
        alert('An error occurred while creating the operator. Please try again later.');
    }
}


function editOperator(id_operator, nama_operator, pass_operator, id_opd) {
    document.getElementById('updateOperatorId').value = id_operator;
    document.getElementById('updateOperatorName').value = nama_operator;
    document.getElementById('updateOperatorPass').value = pass_operator;
    document.getElementById('updateOperatorOpd').value = id_opd;

    new bootstrap.Modal(document.getElementById('updateOperatorModal')).show();
}

async function updateOperator() {
    const id_operator = document.getElementById('updateOperatorId').value;
    const nama_operator = document.getElementById('updateOperatorName').value;
    const pass_operator = document.getElementById('updateOperatorPass').value;
    const id_opd = document.getElementById('updateOperatorOpd').value;

    try {
        const response = await fetch('http://192.168.10.6:8080/Kominfo/service-sijunjung/public/Operator.php', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({ id_operator, nama_operator, pass_operator, id_opd })
        });
        const data = await response.json();
        if (data.success) {
            alert('Operator updated successfully!');
        } else {
            alert('Error updating operator: ' + data.message);
        }
        bootstrap.Modal.getInstance(document.getElementById('updateOperatorModal')).hide();
        
        await fetchOperators();

    } catch (error) {
        console.error('Error updating operator:', error);
    }
}


async function deleteOperator(id_operator) {
    if (confirm('Are you sure you want to delete this operator?')) {
        try {
            const response = await fetch('http://192.168.10.6:8080/Kominfo/service-sijunjung/public/Operator.php', {
                method: 'DELETE',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({ id_operator })
            });
            const data = await response.json();
            if (data.success) {
                alert('Operator deleted successfully!');
            } else {
                alert('Error deleting operator: ' + data.message);
            }
            await fetchOperators();
        } catch (error) {
            console.error('Error deleting operator:', error);
        }
    }
}
</script>
