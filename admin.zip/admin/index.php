<?php
include 'includes/header.php';
?>

<div class="container-fluid">
    <div class="row">
        <?php include 'includes/sidebar.php'; ?>
        <main class="col" id="main-content">
            <script>
                // Check if JWT is present in localStorage
                const jwtToken = localStorage.getItem('jwt');
                if (!jwtToken) {
                    // Redirect to login page or show an error message
                    window.location.href = '../login_adm.php'; // or display a message
                } else {
                    // Load the PHP content if the token is present
                    document.getElementById('main-content').style.display = 'block';
                }
            </script>
            <?php
            // This PHP code will only run if the JavaScript check passes
            if (isset($_GET['page'])) {
                $page = $_GET['page'];
                $allowed_pages = ['masterData','masterData_op','masterData_pengguna','masterData_opd','masterData_layanan', 'historyLayanan', 'laporan'];

                if (in_array($page, $allowed_pages)) {
                    include 'pages_adm/' . $page . '.php';
                } else {
                    echo "Page not found.";
                }
            } else {
                echo "No page selected.";
            }
            ?>
        </main>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
