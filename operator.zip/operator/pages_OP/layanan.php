<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Layanan</title>
    <!-- Include Bootstrap CSS if not already included -->
</head>

<body>
    <main id="main" class="main">
        <div class="pagetitle">
            <h1>Layanan</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php?page=profile">Home</a></li>
                    <li class="breadcrumb-item active">Layanan</li>
                </ol>
            </nav>
        </div><!-- End Page Title -->

        <div class="table-responsive p-3 border rounded" >
            <table id="tiketTable" class="table table-hover table-striped">
                <thead class="thead-dark">
                    <tr>
                        <th>Nama Pengguna</th>
                        <th>Nama Layanan</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Data will be loaded here using JavaScript -->
                </tbody>
            </table>
        </div>

        <!-- Modal Structure for Ticket Details -->
        <div id="ticketModal" class="modal fade" tabindex="-1" aria-labelledby="ticketModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="ticketModalLabel">Detail Tiket</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body" id="modal-body">
                        <!-- Ticket details will be inserted here -->
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary" id="nextBtn">Next</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Modal Structure for Update Process -->
        <div id="updateModal" class="modal fade" tabindex="-1" aria-labelledby="updateModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="updateModalLabel">Update Proses Tiket</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form id="updateForm">
                            <div class="mb-3">
                                <label for="proses" class="form-label">Pilih Proses:</label>
                                <select id="proses" class="form-select" required>
                                    <option value="">-- Pilih Proses --</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="keteranganProses" class="form-label">Keterangan Proses:</label>
                                <textarea id="keteranganProses" class="form-control" rows="3" placeholder="Masukkan keterangan proses..." required></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary">Update Proses</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <script>
            let currentTicketId = null;

            // Function to load data from API
            function loadData() {
                const idOpd = localStorage.getItem('id_opd');
                console.log('ID OPD from localStorage:', idOpd);

                if (!idOpd) {
                    document.querySelector('#tiketTable tbody').innerHTML =
                        '<tr><td colspan="5" class="text-center">ID OPD not found in localStorage.</td></tr>';
                    return;
                }

                fetch('http://192.168.10.6:8080/Kominfo/service-sijunjung/public/Tiket.php?action=tiketdetails')
                    .then(response => response.json())
                    .then(data => {
                        console.log('Data from API:', data);
                        const tbody = document.querySelector('#tiketTable tbody');

                        if (!data || data.length === 0) {
                            tbody.innerHTML = '<tr><td colspan="5" class="text-center">No data available.</td></tr>';
                            return;
                        }

                        const filteredData = data.filter(tiket => tiket.id_opd.toString() === idOpd);

                        if (filteredData.length === 0) {
                            tbody.innerHTML = '<tr><td colspan="5" class="text-center">No data matching ID OPD.</td></tr>';
                        } else {
                            filteredData.forEach(tiket => {
                                const row = document.createElement('tr');
                                row.innerHTML = `
                                    <td>${tiket.nama_pengguna || 'Not available'}</td>
                                    <td>${tiket.nama_layanan || 'Not available'}</td>
                                    <td>${tiket.ket_proses || 'Not available'}</td>
                                    <td><button class="btn btn-primary btn-sm" onclick="viewDetails(${tiket.id_tiket})">Details</button></td>
                                `;
                                tbody.appendChild(row);
                            });
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        document.querySelector('#tiketTable tbody').innerHTML =
                            '<tr><td colspan="5" class="text-center">Error loading data.</td></tr>';
                    });
            }

            // Function to open modal and fetch ticket details
            function viewDetails(idTiket) {
                fetch('http://192.168.10.6:8080/Kominfo/service-sijunjung/public/Tiket.php?action=tiketdetails')
                    .then(response => response.json())
                    .then(data => {
                        const ticket = data.find(tiket => tiket.id_tiket == idTiket);

                        if (ticket) {
                            currentTicketId = ticket.id_tiket; // Store the ID for later use

                            const modalBody = document.getElementById('modal-body');
                            modalBody.innerHTML = `
    <!-- ID Tiket dihapus dari tampilan -->
    <p><strong>Nama Pengguna:</strong> ${ticket.nama_pengguna || 'Not available'}</p>
    <p><strong>Nama OPD:</strong> ${ticket.nama_opd || 'Not available'}</p>
    <p><strong>Nama Layanan:</strong> ${ticket.nama_layanan || 'Not available'}</p>
    <p><strong>Subjek:</strong> ${ticket.subjek || 'Not available'}</p>
    <p><strong>Keterangan:</strong> ${ticket.keterangan || 'Not available'}</p>
    <p><strong>Tanggal Diajukan:</strong> ${ticket.tgl_diajukan || 'Not available'}</p>
    <p><strong>Proses:</strong> ${ticket.ket_proses || 'Not available'}</p>
    <p><strong>Keterangan Proses:</strong> ${ticket.detail_proses || 'Not available'}</p>
    ${ticket.lampiran && ticket.lampiran.length > 0 ? `
        <div class="attachments">
            <strong>Lampiran:</strong>
            <ul>
                ${ticket.lampiran.map(lampiran => `
                    <li><a href="http://192.168.10.6:8080/Kominfo/service-sijunjung/public/Document.php?filename=${encodeURIComponent(lampiran)}" target="_blank" class="pdf-link">${lampiran}</a></li>
                `).join('')}
            </ul>
        </div>
    ` : '<p><strong>Lampiran:</strong> No attachments.</p>'}
`;


                            // Show the modal
                            const modal = new bootstrap.Modal(document.getElementById('ticketModal'));
                            modal.show();

                            // Add event listener for the "Next" button to open the update modal
                            document.getElementById('nextBtn').addEventListener('click', function () {
                                loadProcessOptions();
                                const updateModal = new bootstrap.Modal(document.getElementById('updateModal'));
                                updateModal.show();
                            });
                        } else {
                            alert('Ticket details not found.');
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        alert('Error loading ticket details.');
                    });
            }

            // Function to load process options from the API
            function loadProcessOptions() {
                fetch('http://192.168.10.6:8080/Kominfo/service-sijunjung/public/Proses.php')
                    .then(response => response.json())
                    .then(data => {
                        const processSelect = document.getElementById('proses');
                        processSelect.innerHTML = '<option value="">-- Pilih Proses --</option>'; // Reset options

                        data.forEach(proses => {
                            const option = document.createElement('option');
                            option.value = proses.id_proses;
                            option.textContent = proses.ket_proses;
                            processSelect.appendChild(option);
                        });
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        alert('Error loading process options.');
                    });
            }

            // Event listener for form submission
            document.getElementById('updateForm').addEventListener('submit', function (event) {
                event.preventDefault();

                if (!currentTicketId) {
                    alert('Ticket ID is not available.');
                    return;
                }

                const idProses = document.getElementById('proses').value;
                const detailProses = document.getElementById('keteranganProses').value;

                if (!idProses || !detailProses) {
                    alert('Please fill out all required fields.');
                    return;
                }

                const requestData = {
                    id_tiket: currentTicketId,
                    id_proses: idProses,
                    detail_proses: detailProses
                };

                fetch('http://192.168.10.6:8080/Kominfo/service-sijunjung/public/Tiket.php', {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: new URLSearchParams(requestData)
                })
                    .then(response => response.json())
                    .then(data => {
                        console.log('Update response:', data);
                        alert('Ticket process updated successfully!');
                        const updateModal = bootstrap.Modal.getInstance(document.getElementById('updateModal'));
                        updateModal.hide();

                        window.location.reload();
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        alert('Failed to update ticket process.');
                    });
            });

            // Load data when the page is ready
            document.addEventListener('DOMContentLoaded', loadData);
        </script>
    </main>
</body>

</html>
