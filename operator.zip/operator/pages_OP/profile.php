<main id="main" class="main">
    <div class="pagetitle">
        <h1>Profile</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php?page=profile">Home</a></li>
                <li class="breadcrumb-item active">Profile</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <section class="section profile">
        <div class="row">
            <div class="col-xl-4">
                <div class="card">
                    <div class="card-body profile-card pt-4 d-flex flex-column align-items-center">
                        <div id="profileImageContainer"></div>
                        <h2 id="profileName"></h2>
                    </div>
                </div>
            </div>

            <div class="col-xl-8">
                <div class="card">
                    <div class="card-body pt-3">
                        <!-- Bordered Tabs -->
                        <ul class="nav nav-tabs nav-tabs-bordered">

                            <li class="nav-item">
                                <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#profile-overview">Overview</button>
                            </li>

                            <li class="nav-item">
                                <button class="nav-link" data-bs-toggle="tab" data-bs-target="#profile-details">Details</button>
                            </li>

                        </ul>
                        <div class="tab-content pt-2">

                            <div class="tab-pane fade show active profile-overview" id="profile-overview">
                                <div id="visionMissionContainer"></div>
                            </div>

                            <div class="tab-pane fade profile-edit pt-3" id="profile-details">
                                <div id="detailsContainer"></div>
                            </div>

                        </div><!-- End Bordered Tabs -->

                    </div>
                </div>
            </div>
        </div>
    </section>

    <div class="loader" id="loader"></div> <!-- Loader -->
</main><!-- End #main -->

<script>
    document.addEventListener('DOMContentLoaded', async function () {
        const loader = document.getElementById('loader');
        loader.style.display = 'block'; // Show loader

        const idOpd = localStorage.getItem('id_opd');
        const namaOperator = localStorage.getItem('nama_operator');
        const jwt = localStorage.getItem('jwt');

        if (!namaOperator || !jwt) {
            window.location.href = 'login.html';
            return;
        }

        try {
            const response = await fetch(`http://192.168.10.6:8080/Kominfo/service-sijunjung/public/Opd.php?id_opd=${idOpd}`, {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${jwt}`,
                    'Content-Type': 'application/json'
                }
            });

            const text = await response.text();

            let data;
            try {
                data = JSON.parse(text);
            } catch (e) {
                document.getElementById('dataContainer').innerText = 'Failed to parse JSON response.';
                loader.style.display = 'none'; // Hide loader
                return;
            }

            if (data) {
                document.getElementById('profileName').innerText = data.nama_opd;

                document.getElementById('profileImageContainer').innerHTML = `
                    <img src="http://192.168.10.6:8080/Kominfo/service-sijunjung/asset/images/${data.logo_opd}" alt="Logo OPD" >
                `;

                document.getElementById('visionMissionContainer').innerHTML = `
                    <p><strong>Visi:</strong> ${data.visi}</p>
                    <p><strong>Misi:</strong> ${data.misi}</p>
                `;

                document.getElementById('detailsContainer').innerHTML = `
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item"><strong>Nama Operator:</strong> ${namaOperator}</li>
                        <li class="list-group-item"><strong>Alamat:</strong> ${data.alamat_opd}</li>
                        <li class="list-group-item"><strong>Deskripsi:</strong> ${data.deskripsi}</li>
                        <li class="list-group-item"><strong>Nomor Telpon:</strong> ${data.no_telp}</li>
                        <li class="list-group-item"><strong>Email:</strong> ${data.email_opd}</li>
                    </ul>
                `;
            } else {
                document.getElementById('dataContainer').innerText = 'Failed to load data: Unknown error occurred';
            }
            loader.style.display = 'none'; // Hide loader
        } catch (error) {
            document.getElementById('dataContainer').innerText = `An error occurred: ${error.message}`;
            loader.style.display = 'none'; // Hide loader
        }
    });
</script>
