<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logbook</title>
    <!-- Include Bootstrap CSS if not already included -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/5.3.3/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <main id="main" class="main">
        <div class="pagetitle">
            <h1>Logbook</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php?page=profile">Home</a></li>
                    <li class="breadcrumb-item active">Logbook</li>
                </ol>
            </nav>
        </div><!-- End Page Title -->

        <div class="table-responsive p-3 border rounded" >
            <table id="tiketTable" class="table table-hover table-striped">
                <thead class="thead-dark">
                    <tr>
                        <th>No</th> <!-- Added Numbering Column -->
                        <th>Nama Pengguna</th>
                        <th>Nama Layanan</th>
                        <th>Email</th>
                        <th>Keterangan</th>
                        <th>Detail Proses</th>
                        <th>Keterangan Proses</th>
                        <th>Tanggal</th>
                        <th>Lampiran</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Data will be loaded here using JavaScript -->
                </tbody>
            </table>
        </div>

        <!-- Modal Structure for Ticket Details -->
        <div id="ticketModal" class="modal fade" tabindex="-1" aria-labelledby="ticketModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="ticketModalLabel">Detail Tiket</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body" id="modal-body">
                        <!-- Ticket details will be inserted here -->
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary" id="nextBtn">Next</button>
                    </div>
                </div>
            </div>
        </div>

        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.3.3/js/bootstrap.bundle.min.js"></script>
        <script>
            document.addEventListener('DOMContentLoaded', () => {
                loadData();

                document.getElementById('updateForm').addEventListener('submit', (event) => {
                    event.preventDefault();
                    updateProcess();
                });
            });

            function loadData() {
                const idOpd = localStorage.getItem('id_opd');
                console.log('ID OPD from localStorage:', idOpd);

                if (!idOpd) {
                    document.querySelector('#tiketTable tbody').innerHTML =
                        '<tr><td colspan="9" class="text-center">ID OPD not found in localStorage.</td></tr>';
                    return;
                }

                fetch('http://192.168.10.6:8080/Kominfo/service-sijunjung/public/Tiket.php?action=tiketdetails')
                    .then(response => response.json())
                    .then(data => {
                        console.log('Data from API:', data);
                        const tbody = document.querySelector('#tiketTable tbody');

                        if (!data || data.length === 0) {
                            tbody.innerHTML = '<tr><td colspan="9" class="text-center">No data available.</td></tr>';
                            return;
                        }

                        const filteredData = data.filter(tiket => tiket.id_opd.toString() === idOpd);

                        tbody.innerHTML = filteredData.length > 0
                            ? filteredData.map((tiket, index) => `
                                <tr>
                                    <td>${index + 1}</td> <!-- Row Number -->
                                    <td>${tiket.nama_pengguna || 'Not available'}</td>
                                    <td>${tiket.nama_layanan || 'Not available'}</td>
                                    <td>${tiket.email || 'Not available'}</td>
                                    <td>${tiket.keterangan || 'Not available'}</td>
                                    <td>${tiket.detail_proses || 'Not available'}</td>
                                    <td>${tiket.ket_proses || 'Not available'}</td>
                                    <td>${tiket.tgl_diajukan || 'Not available'}</td>
                                    <td>${tiket.lampiran && tiket.lampiran.length > 0 ? `
                                        <div class="attachments">
                                            <strong>Lampiran:</strong>
                                            <ul>
                                                ${tiket.lampiran.map(lampiran => `
                                                    <li><a href="http://192.168.10.6:8080/Kominfo/service-sijunjung/public/Document.php?filename=${encodeURIComponent(lampiran)}" target="_blank" class="pdf-link">${lampiran}</a></li>
                                                `).join('')}
                                            </ul>
                                        </div>
                                    ` : '<p><strong>Lampiran:</strong> No attachments.</p>'}</td>
                                </tr>
                            `).join('')
                            : '<tr><td colspan="9" class="text-center">No data matching ID OPD.</td></tr>';
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        document.querySelector('#tiketTable tbody').innerHTML =
                            '<tr><td colspan="9" class="text-center">Error loading data.</td></tr>';
                    });
            }

        </script>
    </main>
</body>

</html>
