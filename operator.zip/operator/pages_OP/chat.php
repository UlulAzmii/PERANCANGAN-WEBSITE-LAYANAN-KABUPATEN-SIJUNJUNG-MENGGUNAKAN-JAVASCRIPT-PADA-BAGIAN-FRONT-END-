<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Chat</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .chat-container {
            width: 400px;
            background: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            padding: 20px;
            display: flex;
            flex-direction: column;
            height: 500px;
        }
        .messages {
            flex: 1;
            overflow-y: auto;
            border-bottom: 1px solid #ddd;
            margin-bottom: 10px;
            padding-bottom: 10px;
        }
        .message {
            margin-bottom: 10px;
            padding: 10px;
            border-radius: 10px;
            max-width: 75%;
        }
        .message.admin {
            background-color: #d1e7dd;
            align-self: flex-start;
        }
        .message.user {
            background-color: #cce5ff;
            align-self: flex-end;
            text-align: right;
        }
        .message span {
            font-weight: bold;
            display: block;
        }
        .input-container {
            display: flex;
        }
        .input-container textarea {
            flex: 1;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            resize: none;
        }
        .input-container button {
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            background: #007bff;
            color: #fff;
            cursor: pointer;
            margin-left: 10px;
        }
    </style>
</head>
<body>
    <div class="chat-container">
        <div class="messages" id="messages">
            <!-- Pesan akan ditampilkan di sini -->
        </div>
        <div class="input-container">
            <textarea id="messageInput" rows="3" placeholder="Ketik pesan..."></textarea>
            <button id="sendMessage">Kirim</button>
        </div>
    </div>

    <script>
        const apiUrl = 'http://192.168.10.6:8080/Kominfo/service-sijunjung/public/Chat.php';
        const idOpd = localStorage.getItem('id_opd'); // Mengambil id_opd dari localStorage
        const idAdmin = localStorage.getItem('id_admin'); // Mengambil id_admin dari localStorage

        document.getElementById('sendMessage').addEventListener('click', function() {
            var messageInput = document.getElementById('messageInput');
            var messages = document.getElementById('messages');
            var message = messageInput.value.trim();

            if (message !== '' && idOpd) {
                // Kirim pesan ke API
                fetch(apiUrl, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: new URLSearchParams({
                        'action': 'create',
                        'id_opd': idOpd,
                        'chat': message
                    })
                })
                .then(response => response.text())
                .then(data => {
                    // Tampilkan pesan di area chat
                    var messageDiv = document.createElement('div');
                    messageDiv.classList.add('message', idAdmin ? 'admin' : 'user');
                    messageDiv.innerHTML = '<span>' + (idAdmin ? 'Admin' : 'Pengguna') + ':</span>' + message;
                    
                    messages.appendChild(messageDiv);
                    messageInput.value = '';
                    messages.scrollTop = messages.scrollHeight; // Scroll ke bawah
                    
                    // Refresh chat messages
                    loadMessages();
                })
                .catch(error => console.error('Error:', error));
            } else {
                console.error('ID OPD tidak ditemukan di localStorage.');
            }
        });

        function loadMessages() {
            fetch(`${apiUrl}?id_opd=${idOpd}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                }
            })
            .then(response => response.json())
            .then(data => {
                var messages = document.getElementById('messages');
                messages.innerHTML = ''; // Kosongkan area chat
                
                data.forEach(chat => {
                    var messageDiv = document.createElement('div');
                    messageDiv.classList.add('message', chat.id_admin ? 'admin' : 'user');
                    messageDiv.innerHTML = '<span>' + (chat.id_admin ? 'Admin' : 'Pengguna') + ':</span>' + chat.chat;
                    
                    messages.appendChild(messageDiv);
                });

                messages.scrollTop = messages.scrollHeight; // Scroll ke bawah
            })
            .catch(error => console.error('Error:', error));
        }

        // Load messages saat halaman dimuat
        document.addEventListener('DOMContentLoaded', loadMessages);
    </script>
</body>
</html>
