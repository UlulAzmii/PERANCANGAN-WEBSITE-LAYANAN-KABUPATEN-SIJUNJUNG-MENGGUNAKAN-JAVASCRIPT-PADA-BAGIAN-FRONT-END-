<?php
include 'includes/header.php';
?>

<div class="container-fluid">
    <div class="row">
        <?php include 'includes/sidebar.php'; ?>
        <main class="col">
            <div id="main-content" style="display: none;">
                <?php
                // Memuat konten halaman berdasarkan parameter 'page'
                if (isset($_GET['page'])) {
                    $page = $_GET['page'];
                    $allowed_pages = ['profile', 'layanan', 'logbook', 'detail_tiket'];

                    if (in_array($page, $allowed_pages)) {
                        include 'pages_OP/' . $page . '.php';
                    } else {
                        echo "Page not found.";
                    }
                } else {
                    echo "No page selected.";
                }
                ?>
            </div>
            <script>
                // Check if JWT is present in localStorage
                const jwtToken = localStorage.getItem('jwt');
                if (!jwtToken) {
                    // Redirect to login page or show an error message
                    window.location.href = '../login_OP.php'; // Redirect to login page
                } else {
                    // Show the main content if the token is present
                    document.getElementById('main-content').style.display = 'block';
                }
            </script>
        </main>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
