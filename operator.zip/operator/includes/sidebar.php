<style>
    /* Sidebar styles */
    #sidebarMenu {
        top: 0;
        height: 100vh;
        width: 300px;
        background-color: #fff;
        border-right: 1px solid #ddd;
        padding-top: 60px; /* Offset for fixed header */
        overflow-y: auto;
        z-index: 996;
        transition: all 0.3s;
        box-shadow: 0px 0px 20px rgba(1, 41, 112, 0.1);
    }

    /* Scrollbar styles */
    #sidebarMenu::-webkit-scrollbar {
        width: 5px;
    }

    #sidebarMenu::-webkit-scrollbar-thumb {
        background-color: #aab7cf;
    }

    /* Navbar link styles */
    .nav-link {
        display: flex;
        align-items: center;
        padding: 10px 15px;
        color: #333;
        font-weight: 500;
        border-radius: 4px;
        transition: background-color 0.3s ease, color 0.3s ease;
        margin-bottom: 5px;
    }

    .nav-link:hover,
    .nav-link.active {
        background-color: #007bff;
        color: #fff;
    }

    .mdi {
        margin-right: 10px;
        font-size: 1.2em;
    }

    /* Profile link section */
    .profile-link {
        margin-top: 20px;
        border-top: 1px solid #ddd;
        padding-top: 10px;
    }

    /* Loader styles */
    .loader {
        display: none; /* Hidden by default */
        border: 8px solid #f3f3f3;
        border-radius: 50%;
        border-top: 8px solid #3498db;
        width: 50px;
        height: 50px;
        animation: spin 1s linear infinite;
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        z-index: 1000;
    }

    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }

    /* Adjustments for screen size */
    @media (max-width: 1199px) {
        #sidebarMenu {
            left: -300px;
        }

        .toggle-sidebar #sidebarMenu {
            left: 0;
        }
    }

    @media (min-width: 1200px) {
        #main,
        #footer {
            margin-left: 300px;
        }
    }
</style>

<nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block sidebar collapse">
    <div class="position-sticky pt-3">
        <ul class="nav flex-column sidebar-nav">
            <li class="nav-item">
                <a class="nav-link" href="index.php?page=profile">
                    <span class="mdi mdi-account-circle-outline"></span>
                    Profile
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="index.php?page=layanan">
                    <span class="mdi mdi-tools"></span>
                    Layanan
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="index.php?page=logbook">
                    <span class="mdi mdi-book-open-variant"></span>
                    Logbook Layanan
                </a>
            </li>
            <li class="nav-item profile-link">
                <a class="nav-link" href="#" id="logoutLink" data-bs-toggle="modal" data-bs-target="#logoutModal">
                    <span class="mdi mdi-logout"></span>
                    Log Out
                </a>
            </li>
        </ul>
    </div>
</nav>

<!-- Loader Element -->
<div class="loader" id="loader"></div>

<!-- Logout Confirmation Modal -->
<div class="modal fade" id="logoutModal" tabindex="-1" aria-labelledby="logoutModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="logoutModalLabel">Confirm Logout</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                Are you sure you want to log out?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" id="confirmLogout">Log Out</button>
            </div>
        </div>
    </div>
</div>

<script>
    // Get all nav-link elements
    const navLinks = document.querySelectorAll('.nav-link');

    // Get the current URL
    const currentUrl = window.location.href;

    // Add the 'active' class to the link that matches the current URL
    navLinks.forEach(link => {
        if (link.href === currentUrl) {
            link.classList.add('active');
        }

        // Add event listener to handle link click
        link.addEventListener('click', function() {
            // Remove 'active' class from all links
            navLinks.forEach(link => link.classList.remove('active'));
            
            // Add 'active' class to the clicked link
            this.classList.add('active');
        });
    });

    // Show logout modal
    document.getElementById('logoutLink').addEventListener('click', function(event) {
        event.preventDefault();
    });

    // Handle logout functionality with loader
    document.getElementById('confirmLogout').addEventListener('click', function() {
        const loader = document.getElementById('loader');
        loader.style.display = 'block'; // Show loader

        setTimeout(() => {
            localStorage.removeItem('jwt');
            localStorage.removeItem('nama');
            localStorage.clear();
            window.location.href = '../login_OP.php';
        }, 1000); // 1-second delay to show the loader
    });
</script>
