<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Operator Panel</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.materialdesignicons.com/5.4.55/css/materialdesignicons.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/img/service-tool.png" rel="icon">
    <link href="https://fonts.gstatic.com" rel="preconnect">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
    <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
    <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
    <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">
    <style>
        .custom-logo {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 46px;
            height: 42px;
            border-radius: 1% 1% 35% 35%;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.5);
            margin-right: 10px;
            background-color: #fff;
            transition: transform 0.3s ease-in-out;
        }
        .custom-logo img {
            max-width: 100%;
            height: auto;
            transition: transform 0.3s ease-in-out;
        }
        .custom-logo:hover img {
            transform: rotate(360deg);
        }
        .navbar-nav .nav-item .nav-link {
            color: white;
        }
        .navbar {
            height: 65px;
        }
        .navbar-brand span {
            font-size: 18px;
            margin-bottom: 0;
            font-weight: 600;
            color: white;
        }
        .navbar, .header {
            background-color: #007bff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.5);
        }
        body {
            font-family: 'Roboto', Arial, sans-serif;
            font-size: 1rem;
            color: inherit;
        }
        .bi-list.toggle-sidebar-btn {
            color: white;
        }
        .chat-button {
            position: fixed;
            bottom: 20px;
            right: 20px;
            z-index: 1000;
        }
        .modal-dialog {
            max-width: 600px;
        }
        .chat-container {
            display: flex;
            flex-direction: column;
            height: 400px;
            overflow: hidden;
            background-color: #f0f0f0;
        }
        .messages {
            flex: 1;
            overflow-y: auto;
            padding: 10px;
            background-color: #e5ddd5;
        }
        .message {
            margin-bottom: 10px;
            padding: 10px;
            border-radius: 10px;
            background-color: #fff;
            position: relative;
            max-width: 70%;
        }
        .message.admin {
            background-color: #dcf8c6;
            align-self: flex-end;
        }
        .message.user {
            background-color: #ffffff;
            align-self: flex-start;
        }
        .message span {
            font-weight: bold;
        }
        .message .timestamp {
            font-size: 0.75rem;
            color: #999;
            position: absolute;
            bottom: 5px;
            right: 10px;
        }
        .input-container {
            display: flex;
            flex-direction: column;
            padding: 10px;
            background-color: #fff;
            border-top: 1px solid #ddd;
        }
        #messageInput {
            resize: none;
        }
        .modal-header {
            background-color: #007bff;
            color: #fff;
        }
        .modal-footer {
            background-color: #f1f1f1;
        }
    </style>
</head>
<body>

    <!-- ======= Header ======= -->
    <header id="header" class="header fixed-top d-flex align-items-center">

        <div class="d-flex align-items-center justify-content-between">
            <div class="custom-logo">
                <img src="assets/img/service-tool.png" alt="Logo">
            </div>
            <a class="navbar-brand d-flex align-items-center" href="#">
                <span class="d-none d-lg-block">OPERATOR SERVICE</span>
            </a>
            <i class="bi bi-list toggle-sidebar-btn"></i>
        </div>

    <nav class="header-nav ms-auto">
      <ul class="d-flex align-items-center">

      </nav>

        </header>
    <!-- End Header -->

    <!-- Chat Button -->
    <button type="button" class="btn btn-primary chat-button" data-bs-toggle="modal" data-bs-target="#chatModal">
        <i class="bi bi-chat-dots"></i>
    </button>

    <!-- Chat Modal -->
<div class="modal fade" id="chatModal" tabindex="-1" aria-labelledby="chatModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="chatModalLabel">Chat</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="chat-container">
                    <div class="messages" id="messages">
                        <!-- Messages will be displayed here -->
                    </div>
                    <div class="input-container mt-3">
                        <textarea id="messageInput" class="form-control" rows="3" placeholder="Type your message..."></textarea>
                        <button id="sendMessage" class="btn btn-primary mt-2">Send</button>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

    <!-- Vendor JS Files -->
    <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/vendor/chart.js/chart.umd.js"></script>
    <script src="assets/vendor/echarts/echarts.min.js"></script>
    <script src="assets/vendor/quill/quill.js"></script>
    <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
    <script src="assets/vendor/tinymce/tinymce.min.js"></script>
    <script src="assets/vendor/php-email-form/validate.js"></script>

    <!-- Template Main JS File -->
    <script src="assets/js/main.js"></script>

    <script>
    const apiUrl = 'http://192.168.10.6:8080/Kominfo/service-sijunjung/public/Chat.php';
    const idOpd = localStorage.getItem('id_opd'); // Get id_opd from localStorage
    const idAdmin = localStorage.getItem('id_admin'); // Get id_admin from localStorage

    document.getElementById('sendMessage').addEventListener('click', function() {
        var messageInput = document.getElementById('messageInput');
        var messages = document.getElementById('messages');
        
        var message = messageInput.value.trim();

        if (message !== '' && idOpd) {
            // Send message to API
            fetch(apiUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams({
                    'action': 'create',
                    'id_opd': idOpd,
                    'chat': message
                })
            })
            .then(response => response.text())
            .then(data => {
                // Display message in chat area
                var messageDiv = document.createElement('div');
                messageDiv.classList.add('message', idAdmin ? 'admin' : 'user');
                var timestamp = new Date().toLocaleTimeString(); // Current time
                messageDiv.innerHTML = `<span>${idAdmin ? 'Admin' : 'You'}:</span> ${message}<div class="timestamp">${timestamp}</div>`;
                
                messages.appendChild(messageDiv);
                messageInput.value = '';
                messages.scrollTop = messages.scrollHeight; // Scroll to bottom
                
                // Refresh chat messages
                loadMessages();
            })
            .catch(error => console.error('Error:', error));
        } else {
            console.error('ID OPD not found in localStorage or empty message.');
        }
    });

    function loadMessages() {
        fetch(`${apiUrl}?id_opd=${idOpd}`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            }
        })
        .then(response => response.json())
        .then(data => {
            var messages = document.getElementById('messages');
            messages.innerHTML = ''; // Clear chat area
            
            data.forEach(chat => {
                var messageDiv = document.createElement('div');
                messageDiv.classList.add('message');
                messageDiv.classList.add(chat.id_admin ? 'admin' : 'user');
                messageDiv.innerHTML = `<span>${chat.id_admin ? 'Admin' : 'You'}:</span> ${chat.chat}<div class="timestamp">${chat.chatTime}</div>`;
                
                messages.appendChild(messageDiv);
            });

            messages.scrollTop = messages.scrollHeight; // Scroll to bottom
        })
        .catch(error => console.error('Error:', error));
    }

    document.addEventListener('DOMContentLoaded', loadMessages);

        // Refresh messages setiap 3 detik
        setInterval(loadMessages, 3000);
</script>

</body>
</html>
